<?php

return [
    // Translation keys
];
