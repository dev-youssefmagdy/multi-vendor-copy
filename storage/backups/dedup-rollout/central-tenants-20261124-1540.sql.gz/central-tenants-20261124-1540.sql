-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: dokan_v2
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `data` json DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES ('0fc05b74-b605-4fa7-8d79-dfab8c50bab1',NULL,'2026-11-07 17:40:53','2026-11-07 19:11:32','{\"name\": \"rrr\", \"slug\": \"rrr\", \"email\": \"joe@gg.ccc\", \"phone\": \"+201558099183\", \"status\": \"active\", \"password\": null, \"shop_name\": \"rrr\", \"created_at\": \"2026-11-07 19:40:53\", \"package_id\": 2, \"updated_at\": \"2026-11-07 19:40:53\", \"country_ids\": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198], \"sync_status\": \"ready\", \"account_type\": \"individual\", \"activated_at\": \"2026-11-07 19:40:53\", \"category_ids\": null, \"launch_ready\": true, \"trial_ends_at\": \"2026-12-07 19:40:53\", \"remember_token\": null, \"tenancy_db_name\": \"dokan_v2_0fc05b74-b605-4fa7-8d79-dfab8c50bab1\", \"provision_status\": \"ready\", \"profit_percentage\": 25, \"compliance_version\": \"743dd19c90b565aba03280eabe1e611a\", \"primary_language_id\": 1, \"compliance_accepted_at\": \"2026-11-07 19:40:29\", \"sync_completed_section\": \"coupons\"}',NULL),('6e70e6e5-49d5-40cf-b66c-675dedf2c8dd',NULL,'2026-10-24 09:03:22','2026-11-23 20:24:46','{\"name\": \"vendor\", \"slug\": \"vendor\", \"email\": \"eljoe1717@gmail.com\", \"phone\": \"+201558099183\", \"status\": \"active\", \"address\": \"asdasdas\", \"password\": null, \"shop_name\": \"vendor\", \"created_at\": \"2026-10-24 12:03:22\", \"package_id\": 2, \"updated_at\": \"2026-10-24 12:03:22\", \"country_ids\": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198], \"description\": \"asdasd\", \"sync_status\": \"ready\", \"account_type\": \"individual\", \"activated_at\": \"2026-10-24 12:03:22\", \"category_ids\": null, \"launch_ready\": true, \"trial_ends_at\": \"2026-11-23 12:03:22\", \"catalog_source\": {\"badges\": \"central\", \"labels\": \"central\", \"coupons\": \"central\", \"products\": \"central\", \"categories\": \"central\", \"flash-sales\": \"central\"}, \"remember_token\": null, \"tenancy_db_name\": \"dokan_v2_6e70e6e5-49d5-40cf-b66c-675dedf2c8dd\", \"provision_status\": \"ready\", \"profit_percentage\": 25, \"compliance_version\": \"743dd19c90b565aba03280eabe1e611a\", \"primary_language_id\": 1, \"compliance_accepted_at\": \"2026-10-24 12:04:09\", \"sync_completed_section\": \"coupons\"}',NULL),('d2a5bdc4-a66d-47e1-bf84-7fdc5c62aecf',NULL,'2026-11-07 16:59:58','2026-11-23 20:00:11','{\"name\": \"vvv\", \"slug\": \"vvv\", \"email\": \"eljoe1717@gmail.com\", \"phone\": \"+201558099183\", \"status\": \"active\", \"password\": null, \"shop_name\": \"vvv\", \"created_at\": \"2026-11-07 18:59:58\", \"package_id\": 2, \"updated_at\": \"2026-11-07 18:59:58\", \"country_ids\": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198], \"sync_status\": \"ready\", \"account_type\": \"individual\", \"activated_at\": \"2026-11-07 18:59:58\", \"category_ids\": null, \"launch_ready\": true, \"trial_ends_at\": \"2026-12-07 18:59:58\", \"catalog_source\": {\"badges\": \"central\", \"labels\": \"central\", \"coupons\": \"central\", \"products\": \"central\", \"categories\": \"central\", \"flash-sales\": \"central\"}, \"remember_token\": null, \"tenancy_db_name\": \"dokan_v2_d2a5bdc4-a66d-47e1-bf84-7fdc5c62aecf\", \"provision_status\": \"ready\", \"profit_percentage\": 25, \"compliance_version\": \"743dd19c90b565aba03280eabe1e611a\", \"primary_language_id\": 1, \"compliance_accepted_at\": \"2026-11-07 18:59:01\", \"sync_completed_section\": \"coupons\"}',NULL);
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domains`
--

DROP TABLE IF EXISTS `domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domains` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domains_domain_unique` (`domain`),
  KEY `domains_tenant_id_foreign` (`tenant_id`),
  CONSTRAINT `domains_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domains`
--

LOCK TABLES `domains` WRITE;
/*!40000 ALTER TABLE `domains` DISABLE KEYS */;
INSERT INTO `domains` VALUES (5,'vendor.dokan-v2.loc','6e70e6e5-49d5-40cf-b66c-675dedf2c8dd','2026-10-24 09:03:22','2026-10-24 09:03:22'),(6,'vvv.dokan-v2.loc','d2a5bdc4-a66d-47e1-bf84-7fdc5c62aecf','2026-11-07 16:59:58','2026-11-07 16:59:58'),(7,'rrr.dokan-v2.loc','0fc05b74-b605-4fa7-8d79-dfab8c50bab1','2026-11-07 17:40:53','2026-11-07 17:40:53');
/*!40000 ALTER TABLE `domains` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-24 15:40:25
